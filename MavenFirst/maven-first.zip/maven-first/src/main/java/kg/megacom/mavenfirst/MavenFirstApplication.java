package kg.megacom.mavenfirst;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MavenFirstApplication {

	public static void main(String[] args) {
		SpringApplication.run(MavenFirstApplication.class, args);
	}

}
