package kg.megacom.mavenfirst;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MavenFirstApplicationTests {

	@Test
	void contextLoads() {
	}

}
